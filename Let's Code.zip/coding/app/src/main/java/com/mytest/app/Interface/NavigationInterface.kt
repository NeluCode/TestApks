package com.mytest.app.Interface

interface NavigationInterface {
    fun Position(pos: Int)
}