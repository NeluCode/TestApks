package com.mytest.app.Interface

interface ClickInterface {
    fun Click(link: String, pos: Int, task: String)
}