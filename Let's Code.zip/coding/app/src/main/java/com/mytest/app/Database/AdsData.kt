package com.mytest.app.Database

import android.content.Context

class AdsData(private val context: Context) {

    companion object {
        private val DATA_NAME = "ADS_DATA"
        private val FACEBOOK = "FACEBOOK"
        private val FACEBOOK_INT = "FACEBOOK_INT"
        private val GOOGLE = "GOOGLE"
        private val GOOGLE_INT = "GOOGLE_INT"
        private val TYPE = "TYPE"

        const val NO = 0
        const val GO = 1
        const val FB = 2
    }

    var facebook: String
        get() {
            val prefs = context.getSharedPreferences(DATA_NAME, 0)
            return prefs.getString(FACEBOOK, "")!!
        }
        set(value) {
            val sharedPref = context.getSharedPreferences(DATA_NAME, 0)
            val editor = sharedPref.edit()
            editor.putString(FACEBOOK, value)
            editor.apply()
        }

    var facebookInt: String
        get() {
            val prefs = context.getSharedPreferences(DATA_NAME, 0)
            return prefs.getString(FACEBOOK_INT, "")!!
        }
        set(value) {
            val sharedPref = context.getSharedPreferences(DATA_NAME, 0)
            val editor = sharedPref.edit()
            editor.putString(FACEBOOK_INT, value)
            editor.apply()
        }

    var google: String
        get() {
            val prefs = context.getSharedPreferences(DATA_NAME, 0)
            return prefs.getString(GOOGLE, "")!!
        }
        set(value) {
            val sharedPref = context.getSharedPreferences(DATA_NAME, 0)
            val editor = sharedPref.edit()
            editor.putString(GOOGLE, value)
            editor.apply()
        }

    var googleInt: String
        get() {
            val prefs = context.getSharedPreferences(DATA_NAME, 0)
            return prefs.getString(GOOGLE_INT, "")!!
        }
        set(value) {
            val sharedPref = context.getSharedPreferences(DATA_NAME, 0)
            val editor = sharedPref.edit()
            editor.putString(GOOGLE_INT, value)
            editor.apply()
        }

    var type: Int
        get() {
            val prefs = context.getSharedPreferences(DATA_NAME, 0)
            return prefs.getInt(TYPE, FB)
        }
        set(value) {
            val sharedPref = context.getSharedPreferences(DATA_NAME, 0)
            val editor = sharedPref.edit()
            editor.putInt(TYPE, value)
            editor.apply()
        }
}